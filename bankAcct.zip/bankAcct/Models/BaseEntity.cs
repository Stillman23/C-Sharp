namespace BankAccts.Models{
    public abstract class BaseEntity{}
}