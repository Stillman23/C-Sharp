using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace dojoSurvey.Controllers
{
    public class SurveyController : Controller
    {
        [HttpGet]
        [Route("")]
        [Route("index")]
        public IActionResult index()
        {
            ViewBag.Errors = new List<string>();
            return View();
            
        }

        [HttpPost]
        [Route("process")]
        public IActionResult process(string Name, string Location, string Language, string Comment)
        {
            ViewBag.Errors = new List<string>();

            if(Name == null)

            {
                ViewBag.Errors.Add("Name cannot be empty");
            }

            if(Location == null)
            {
                ViewBag.Errors.Add("Please select a valid location");
            }

            if(Language == null)
            {
                ViewBag.Errors.Add("Please select a valid language");
            }

            if(Comment == null)
            {
                Comment = "";
            }

            if(ViewBag.Errors.Count > 0)
            {
                return View("index");
            }
            
            ViewBag.Name = Name;
            ViewBag.Location = Location;
            ViewBag.Language = Language;
            ViewBag.Comment = Comment;
            
        

        return View("Results");

       
        }
    }
}