﻿using System;
using System.Collections.Generic;

namespace Collections_Assignments
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int[] numArray = new int[9];
            for(int i = 0;i<=9; i++ )
            {
                Console.WriteLine(i);
            }
            string[] names = new string[4]{"Tim", "Martin", "Nikki", "Sara"};
            foreach (string str in names)
            {
                Console.WriteLine(str);
            }

            for (int i = 0; i <=10; i++){
            if ((i % 2) == 0){
                Console.WriteLine(true);

            }
            else{
                Console.WriteLine(false);
            }
            }

            for(int i = 1; i <=10; i++){
                int[] timeArray = new int[10];
                for (int j = 1; j <= 10; j++)
                {
                    timeArray[j-1] = i * j;

                }

                Console.WriteLine("[" + string.Join(",", timeArray)+ "]");

            }

            List<string> Flavors = new List<string>();
            Flavors.Add("Chocolate");
            Flavors.Add("Vanilla");
            Flavors.Add("strawberry");
            Flavors.Add("Caramel");
            Flavors.Add("Pecan");

            Console.WriteLine(Flavors.Count);
            Console.WriteLine(Flavors[2]);
            Flavors.RemoveAt(3);
            Console.WriteLine(Flavors.Count);

            Dictionary<string,string> user = new Dictionary<string,string>();
            user.Add("Tim", null);
            user.Add("Martin", null);
            user.Add("Nikki", null);
            user.Add("Sara", null);
            Random rand = new Random();
            foreach (string name in arr2){
                user[name] = Flavors[rand.Next(0,4)];
            }
            foreach (KeyValuePair<string,string> entry in user){
                Console.WriteLine(entry.Key + " - " + entry.Value);
            }

        }
    }
}
