using Microsoft.EntityFrameworkCore;
 
namespace RESTauranter.Models
{
    public class Homecontext : DbContext
    {
        // base() calls the parent class' constructor passing the "options" parameter along
        public Homecontext(DbContextOptions<Homecontext> options) : base(options) { }

        public DbSet<Person> Users{get; set;}
    }
}