using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
 
namespace RESTauranter.Models
{
    public abstract class  BaseEntity
    {
        // Class definition}
}

public class User: BaseEntity
{
    [Key]
        public long Id { get; set; }
 
        [Required]
        [Display(Name="Reviewer Name")]
        public string Name { get; set; }
 
        [Required]
        [Display(Name="Restaurant Name")]
        public string RestaurantName { get; set; }
 
        [Required]
        [Display(Name="Review")]
        [MinLength(10)]
        public string Review { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name="Date of Visit")]
        public DateTime Created_at { get; set; }

        [Required]
        [Display(Name="Stars")]
        [Range(1,5)]
        public short Rating { get; set; }
    }
}

