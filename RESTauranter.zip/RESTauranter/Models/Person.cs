namespace RESTauranter.Models
{
    public class Person : BaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string RestaurantName { get; set; }
        public string Review { get; set; }

        public int Rating {get; set;}
        
    }
}